## Module <base_accounting_kit>

#### 23.10.2019
#### Version 13.0.1.0.0
#### ADD
- Initial commit for Odoo 13 accounting

#### 28.10.2019
#### Version 13.0.1.1.1
#### FIX
- Function Asset Changed.

#### 31.10.2019
#### Version 13.0.1.2.1
#### ADD
- Added Budget Management.

#### 31.10.2019
#### Version 13.0.1.3.1
#### FIX
- Bug Fixed 'Recurring payment'

#### 12.11.2019
#### Version 13.0.2.4.1
#### FIX
- Bug Fixed 'asset and report'

#### 08.01.2020
#### Version 13.0.2.4.2
#### FIX
- Bug Fixed multiple payment issue.

#### 20.01.2020
#### Version 13.0.3.4.2
#### FIX
- Bug Fixed reccuring payment templates.

#### 11.02.2020
#### Version 13.0.3.4.3
#### FIX
- Asset depreciation date issue

#### 12.02.2020
#### Version 13.0.4.4.3
#### UPDT
- Dashboard Added

#### 13.02.2020
#### Version 13.0.4.5.3
#### RMV
- Library Removed from dashboard

#### 27.02.2020
#### Version 13.0.4.5.4
#### FIX
- Bug Fixed in asset 'Modify Depreciation'

#### 10.03.2020
#### Version 13.0.4.5.5
#### FIX
- Bug Fixed in recurring

#### 20.03.2020
#### Version 13.0.4.5.6
#### UPDT
- Code Optimized-dashboard

#### 24.04.2020
#### Version 13.0.4.6.7
#### IMP
- Multi Company issue updated.

#### 29.04.2020
#### Version 13.0.4.7.8
#### UPDT
- Report updated.

#### 10.06.2020
#### Version 13.0.4.8.9
#### UPDT
- Comma separator in Dashboard
- Currency symbol position in Dashboard
- Monthly invoice filter in Dashboard
- Check payment issue, in case of multi payment


#### 16.07.2020
#### Version 13.0.4.8.10
#### UPDT
- Multi Company in Dashboard
